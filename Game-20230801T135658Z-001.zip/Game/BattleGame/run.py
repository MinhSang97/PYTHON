import game
if __name__ == "__main__":
    g = game.Game(800,533)
    g.run()
