import sys
sys.stdin = open("0003.inp","r")
sys.stdout = open("0003.out","w")
s = input()
s = s.title()
print(s)