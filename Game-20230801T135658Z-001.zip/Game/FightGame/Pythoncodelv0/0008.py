import sys
sys.stdin = open("0008.inp","r")
sys.stdout = open("0008.out","w")

s = input()
s = s.lower()
print(s)