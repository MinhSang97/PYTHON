import sys
sys.stdin = open("0011.inp","r")
sys.stdout = open("0011.out","w")
s = input()
for i in range(0,len(s)):
    print(s[i])