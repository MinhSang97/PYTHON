import sys
sys.stdin = open("0240.inp","r")
sys.stdout = open("0240.out","w")
