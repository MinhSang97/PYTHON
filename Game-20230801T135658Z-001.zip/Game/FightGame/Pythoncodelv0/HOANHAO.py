import sys
from random import randint
sys.stdin = open("HOANHAO.inp","r")
sys.stdout = open("HOANHAO.out","w")
n = int(input())
s = list(map(int,input().split()))
